﻿namespace PetPalsProject.Services
{
    using PetPalsProject.Models;

    public interface IPetService
    {
        void AddPet(Pet pet);
        void ListAvailablePets();
    }
}


