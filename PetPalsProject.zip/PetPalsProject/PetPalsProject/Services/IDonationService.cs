﻿namespace PetPalsProject.Services
{
    public interface IDonationService
    {
        void RecordCashDonation(string donorName, decimal amount);
    }
}
