﻿using System;

namespace PetPalsProject.Services
{
    public interface IEventService
    {
        void ShowUpcomingEvents();
    }
}
