﻿using System;
using System.Data.SqlClient;
using PetPalsProject.Utilities;

namespace PetPalsProject.Services
{
    public class EventServiceImpl : IEventService
    {
        public void ShowUpcomingEvents()
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT EventID, EventName, EventDate, Location FROM AdoptionEvents ORDER BY EventDate";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                Console.WriteLine("\n--- Upcoming Adoption Events ---");

                bool hasRows = false;
                while (reader.Read())
                {
                    hasRows = true;
                    Console.WriteLine($"ID: {reader["EventID"]} | Name: {reader["EventName"]} | Date: {Convert.ToDateTime(reader["EventDate"]).ToShortDateString()} | Location: {reader["Location"]}");
                }

                if (!hasRows)
                {
                    Console.WriteLine("No upcoming events found.");
                }
            }
        }

    }
}
