﻿using System;
using System.Data.SqlClient;
using PetPalsProject.Utilities;
using PetPalsProject.Exceptions;

namespace PetPalsProject.Services
{
    public class DonationServiceImpl : IDonationService
    {
        public void RecordCashDonation(string donorName, decimal amount)
        {
            if (amount < 10)
            {
                throw new InsufficientFundsException("Donation must be at least $10.");
            }

            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "INSERT INTO Donations (DonorName, DonationAmount, DonationDate) VALUES (@name, @amount, @date)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", donorName);
                cmd.Parameters.AddWithValue("@amount", amount);
                cmd.Parameters.AddWithValue("@date", DateTime.Now);
                cmd.ExecuteNonQuery();
            }

            Console.WriteLine("Thank you! Your donation has been recorded.");
        }
    }
}
