﻿using System;
using System.Data.SqlClient;
using PetPalsProject.Utilities;
using PetPalsProject.Exceptions;

namespace PetPalsProject.Services
{
    public class ParticipantServiceImpl : IParticipantService
    {
        public void RegisterParticipant(string name, string type, int eventId)
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();

                // Optional: Check if Event exists
                SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM AdoptionEvents WHERE EventID = @id", conn);
                checkCmd.Parameters.AddWithValue("@id", eventId);
                int count = (int)checkCmd.ExecuteScalar();
                if (count == 0)
                    throw new AdoptionException("Invalid event ID.");

                string query = "INSERT INTO Participants (ParticipantName, ParticipantType, EventID) VALUES (@name, @type, @eventId)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@type", type);
                cmd.Parameters.AddWithValue("@eventId", eventId);
                cmd.ExecuteNonQuery();
            }

            Console.WriteLine("Participant successfully registered.");
        }
    }
}
