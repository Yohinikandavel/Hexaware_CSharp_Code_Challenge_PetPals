﻿namespace PetPalsProject.Services
{
    using System;
    using System.Data.SqlClient;
    using PetPalsProject.Models;
    using PetPalsProject.Utilities;
    using PetPalsProject.Exceptions;

    public class PetServiceImpl : IPetService
    {
        public void AddPet(Pet pet)
        {
            if (pet.Age <= 0)
                throw new InvalidPetAgeException("Pet age must be a positive number.");
            if (string.IsNullOrEmpty(pet.Name) || string.IsNullOrEmpty(pet.Breed))
                throw new NullPetDataException("Pet name or breed cannot be empty.");

            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "INSERT INTO Pets (Name, Age, Breed, Type, AvailableForAdoption) VALUES (@name, @age, @breed, @type, 1)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", pet.Name);
                cmd.Parameters.AddWithValue("@age", pet.Age);
                cmd.Parameters.AddWithValue("@breed", pet.Breed);
                cmd.Parameters.AddWithValue("@type", pet.GetType().Name);
                cmd.ExecuteNonQuery();
            }

            Console.WriteLine("Pet added successfully.");
        }

        public void ListAvailablePets()
        {
            using (SqlConnection conn = DBConnUtil.GetConnection())
            {
                conn.Open();
                string query = "SELECT Name, Age, Breed, Type FROM Pets WHERE AvailableForAdoption = 1";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine($"Name: {reader["Name"]}, Age: {reader["Age"]}, Breed: {reader["Breed"]}, Type: {reader["Type"]}");
                }
            }
        }
    }
}
