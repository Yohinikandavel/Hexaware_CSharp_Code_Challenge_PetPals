﻿namespace PetPalsProject.Services
{
    public interface IParticipantService
    {
        void RegisterParticipant(string name, string type, int eventId);
    }
}
