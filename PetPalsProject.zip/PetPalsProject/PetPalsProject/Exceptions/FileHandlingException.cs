﻿namespace PetPalsProject.Exceptions
{
    using System;

    public class FileHandlingException : Exception
    {
        public FileHandlingException(string message) : base(message) { }
    }
}
