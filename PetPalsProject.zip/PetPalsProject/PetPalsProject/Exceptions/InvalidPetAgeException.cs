﻿namespace PetPalsProject.Exceptions
{
    using System;

    public class InvalidPetAgeException : Exception
    {
        public InvalidPetAgeException(string message) : base(message) { }
    }   
}

