﻿namespace PetPalsProject.Exceptions
{
    using System;

    public class NullPetDataException : Exception
    {
        public NullPetDataException(string message) : base(message) { }
    }
}
