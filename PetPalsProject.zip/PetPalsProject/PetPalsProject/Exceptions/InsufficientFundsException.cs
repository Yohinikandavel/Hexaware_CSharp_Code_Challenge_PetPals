﻿namespace PetPalsProject.Exceptions
{
    using System;

    public class InsufficientFundsException : Exception
    {
        public InsufficientFundsException(string message) : base(message) { }
    }
}

