﻿namespace PetPalsProject.Exceptions
{
    using System;

    public class AdoptionException : Exception
    {
        public AdoptionException(string message) : base(message) { }
    }
}
