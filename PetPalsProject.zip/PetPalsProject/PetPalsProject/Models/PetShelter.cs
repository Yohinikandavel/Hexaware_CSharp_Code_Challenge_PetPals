﻿using PetPalsProject.Models;
using System;
using System.Collections.Generic;

public class PetShelter
{
    private List<Pet> availablePets = new List<Pet>();

    public void AddPet(Pet pet)
    {
        availablePets.Add(pet);
    }

    public void RemovePet(Pet pet)
    {
        availablePets.Remove(pet);
    }

    public void ListAvailablePets()
    {
        if (availablePets.Count == 0)
        {
            Console.WriteLine("No pets available for adoption.");
        }
        else
        {
            foreach (Pet pet in availablePets)
            {
                Console.WriteLine(pet);
            }
        }
    }

    public List<Pet> GetPets()
    {
        return availablePets;
    }
}
