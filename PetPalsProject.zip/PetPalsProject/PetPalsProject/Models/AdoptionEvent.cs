﻿using System;
using System.Collections.Generic;

public class AdoptionEvent
{
    private List<IAdoptable> participants = new List<IAdoptable>();

    public void RegisterParticipant(IAdoptable participant)
    {
        participants.Add(participant);
    }

    public void HostEvent()
    {
        Console.WriteLine($"Hosting event with {participants.Count} participants...");
        foreach (var p in participants)
        {
            p.Adopt();
        }
    }
}
