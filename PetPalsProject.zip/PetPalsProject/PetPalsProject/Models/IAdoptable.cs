﻿public interface IAdoptable
{
    void Adopt();
}
