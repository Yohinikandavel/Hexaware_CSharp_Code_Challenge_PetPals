﻿namespace PetPalsProject.Utilities
{
    using System.Data.SqlClient;
    using System.Configuration;

    public static class DBConnUtil
    {
        public static SqlConnection GetConnection()
        {
            string connStr = ConfigurationManager.ConnectionStrings["PetPalsDB"].ConnectionString;
            return new SqlConnection(connStr);
        }
    }
}
