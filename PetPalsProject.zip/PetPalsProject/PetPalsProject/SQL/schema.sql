CREATE DATABASE PetPals;

USE PetPals;

CREATE TABLE Pets (
    PetID INT IDENTITY PRIMARY KEY,
    Name VARCHAR(50),
    Age INT,
    Breed VARCHAR(50),
    Type VARCHAR(20),
    AvailableForAdoption BIT
);

CREATE TABLE Donations (
    DonationID INT IDENTITY PRIMARY KEY,
    DonorName VARCHAR(100),
    DonationAmount DECIMAL(10, 2),
    DonationDate DATETIME
);

CREATE TABLE AdoptionEvents (
    EventID INT IDENTITY PRIMARY KEY,
    EventName VARCHAR(100),
    EventDate DATETIME,
    Location VARCHAR(100)
);

CREATE TABLE Participants (
    ParticipantID INT IDENTITY PRIMARY KEY,
    ParticipantName VARCHAR(100),
    ParticipantType VARCHAR(50),
    EventID INT FOREIGN KEY REFERENCES AdoptionEvents(EventID)
);

INSERT INTO AdoptionEvents (EventName, EventDate, Location)
VALUES 
('Summer Paws Fest', '2025-07-20', 'Cuddalore'),
('Paw Meet & Greet', '2025-08-10', 'Pondicherry'),
('Adopt-A-Thon', '2025-09-01', 'Chennai'),
('Furry Friends Day', '2025-07-30', 'Mumbai'),
('Rescue Rally', '2025-08-15', 'Coimbatore');

SELECT * FROM Pets;
SELECT * FROM Donations;
SELECT * FROM AdoptionEvents;
SELECT * FROM Participants;


