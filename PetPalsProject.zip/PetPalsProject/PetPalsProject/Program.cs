﻿using System;
using PetPalsProject.Models;
using PetPalsProject.Services;
using PetPalsProject.Exceptions;

namespace PetPalsProject
{
    class Program
    {
        static void Main(string[] args)
        {
            IPetService petService = new PetServiceImpl();
            IDonationService donationService = new DonationServiceImpl();

            while (true)
            {
                Console.WriteLine("\n--- PetPals Platform ---");
                Console.WriteLine("1. Add Pet");
                Console.WriteLine("2. List Available Pets");
                Console.WriteLine("3. Record Cash Donation");
                Console.WriteLine("4. View Events");            //Updated
                Console.WriteLine("5. Register Participant");   //Updated
                Console.WriteLine("6. Exit");

                Console.Write("Enter your choice: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        try
                        {
                            Console.Write("Enter pet name: ");
                            string name = Console.ReadLine();

                            Console.Write("Enter pet age: ");
                            int age = int.Parse(Console.ReadLine());

                            Console.Write("Enter pet breed: ");
                            string breed = Console.ReadLine();

                            Console.Write("Enter type (Dog/Cat): ");
                            string type = Console.ReadLine();

                            Pet pet;
                            if (type.ToLower() == "dog")
                            {
                                pet = new Dog(name, age, breed, breed); // Using breed again for dog breed
                            }
                            else
                            {
                                pet = new Cat(name, age, breed, "White"); // Default cat color
                            }

                            petService.AddPet(pet);
                        }
                        catch (InvalidPetAgeException e)
                        {
                            Console.WriteLine("Error: " + e.Message);
                        }
                        catch (NullPetDataException e)
                        {
                            Console.WriteLine("Error: " + e.Message);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("Error: " + e.Message);
                        }
                        break;

                    case "2":
                        petService.ListAvailablePets();
                        break;

                    case "3":
                        try
                        {
                            Console.Write("Enter donor name: ");
                            string donor = Console.ReadLine();

                            Console.Write("Enter donation amount: ");
                            decimal amount = decimal.Parse(Console.ReadLine());

                            donationService.RecordCashDonation(donor, amount);
                        }
                        catch (InsufficientFundsException e)
                        {
                            Console.WriteLine("Error: " + e.Message);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("Error: " + e.Message);
                        }
                        break;

                    case "4":
                        IEventService eventService = new EventServiceImpl();
                        eventService.ShowUpcomingEvents();
                        break;

                    //Updated
                    case "5":
                        IParticipantService participantService = new ParticipantServiceImpl();
                        try
                        {
                            Console.Write("Enter participant name: ");
                            string pname = Console.ReadLine();

                            Console.Write("Enter participant type (Shelter/Adopter): ");
                            string ptype = Console.ReadLine();

                            Console.Write("Enter event ID to register for: ");
                            int eid = int.Parse(Console.ReadLine());

                            participantService.RegisterParticipant(pname, ptype, eid);
                        }
                        catch (AdoptionException ex)
                        {
                            Console.WriteLine("Error: " + ex.Message);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Something went wrong: " + ex.Message);
                        }
                        break;

                    case "6":
                        Console.WriteLine("Thank you for using PetPals!");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }
    }
}
